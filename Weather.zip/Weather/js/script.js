
// SELECT ELEMENTS
var iconElement = document.querySelector('.icon');
var input = document.querySelector('.input_text');
var main = document.querySelector('#name');
var country = document.querySelector('#country');
var feelslike = document.querySelector('#feels_like');
var temp = document.querySelector('.temp p');
var desc = document.querySelector('.desc p');
var button= document.querySelector('.submit');

// WHEN THE USER CLICKS ON THE BUTTON SUBMIT
// GET CORRESPONDED WEATHER  FROM API PROVIDER
button.addEventListener('click', function(name){
    fetch('http://api.openweathermap.org/data/2.5/weather?q='+input.value+'&units=metric&appid=dba73c5e5f68c98316e7cc0bd14216e5')
    .then(response => response.json())
    .then(data => {

      var tempValue = Math.floor(data.main.temp);
      data.iconId = data.weather[0].icon
      var nameValue = data.name;
      var countryValue = data.sys.country;
      var descValue = data.weather[0].description;
      var feelslikeValue = Math.floor(data.main.feels_like);


     // DISPLAY WEATHER TO USER
      main.innerHTML = nameValue;
      iconElement.innerHTML = `<img src="icons/${data.iconId}.png"/>`;
      temp.innerHTML = "Currently - "+tempValue+`°<span>C</span>`;
      feelslike.innerHTML= "Feels Like - "+feelslikeValue+`°<span>C</span>`;
      desc.innerHTML = descValue;
      country.innerHTML= countryValue;
    
      input.value =""; 
    }) 
.catch(err => alert("Wrong city name!"));

  })
